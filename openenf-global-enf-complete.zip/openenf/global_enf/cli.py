from __future__ import annotations

import argparse
import json
from pathlib import Path

from .collectors import (
    append_manifest,
    discover_all,
    download_resource,
    validate_archives,
)


def main() -> int:
    parser = argparse.ArgumentParser(description="Discover and archive public power-grid frequency datasets.")
    parser.add_argument("command", choices=("discover", "sync", "validate"))
    parser.add_argument("--data-dir", default="./global_enf_data", help="Directory for raw source files and manifests")
    parser.add_argument("--source", action="append", help="Optional source name filter: NESO, AEMO, Fingrid, Netztransparenz, Zenodo")
    args = parser.parse_args()
    root = Path(args.data_dir).expanduser().resolve()

    if args.command == "validate":
        results = validate_archives(root)
        print(json.dumps(results, indent=2))
        return 0 if all(x["status"] == "ok" or x["status"] == "downloaded_unparsed" for x in results) else 2

    resources, errors = discover_all()
    if args.source:
        wanted = {s.casefold() for s in args.source}
        resources = [r for r in resources if any(s in r.source_name.casefold() or s in r.source_id.casefold() for s in wanted)]
    print(f"\nDiscovered {len(resources)} downloadable resources.")
    if args.command == "discover":
        print(json.dumps([r.__dict__ for r in resources], indent=2))
        return 0 if not errors else 1

    records: list[dict[str, object]] = []
    failed = 0
    for index, resource in enumerate(resources, start=1):
        print(f"[{index}/{len(resources)}] {resource.source_name}: {resource.filename}")
        try:
            records.append(download_resource(resource, root))
        except Exception as exc:
            failed += 1
            records.append({**resource.__dict__, "status": "failed", "error": str(exc)})
            print(f"  [FAILED] {exc}")
    append_manifest(root, records)
    append_manifest(root, [{"source": e["source"], "status": "discovery_failed", "error": e["error"]} for e in errors])
    print(f"\nFinished: {len(records) - failed} downloaded/already present, {failed} download failures, {len(errors)} discovery failures.")
    print(f"Manifest: {root / 'manifest.jsonl'}")
    print("Note: raw files are preserved. Format-specific parsing and conversion are intentionally separate.")
    return 0 if failed == 0 and not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())

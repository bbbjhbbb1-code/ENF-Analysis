# Global ENF data collection layer

This directory adds a source-discovery and raw-archive layer alongside the original OpenENF analysis engine.
It does **not** replace the original C#/TypeScript lookup code.

## Why a separate layer?

The legacy `.freqdb` reader assumes one signed 16-bit frequency deviation per second. Its header only stores
`gridId`, `startDate`, `endDate`, and `baseFrequency`. It cannot faithfully represent 10 Hz data, multiple
measurement stations, per-sample quality flags, or source-specific time zones. Therefore, this collector keeps
original downloads intact first. A later, format-specific normalizer can produce a clearly labelled 1 Hz derivative
for the legacy lookup engine without destroying the raw measurements.

## Supported discovery adapters

- **NESO / Great Britain**: discovers CSV resources through the official CKAN `package_show` API.
- **AEMO / Australia**: discovers annual mainland and Tasmania frequency workbooks from AEMO's official page.
- **Fingrid / Nordic system**: discovers monthly 10 Hz frequency archives exposed on dataset 339.
- **Netztransparenz / Continental Europe**: discovers yearly ZIP archives from February 2012 through June 2022.
- **Zenodo**: queries record metadata and file links for records 7741427, 7809233, 5105820, and 15784548.

Discovery is best-effort: a failure at one provider does not prevent the other providers from being queried.
Providers can change page markup or API schemas; check the generated manifest and errors rather than assuming every
source succeeded.

## Run

Requires Python 3.10+ and uses only the Python standard library.

From the repository root:

```bash
python -m global_enf discover
python -m global_enf sync --data-dir ./global_enf_data
python -m global_enf validate --data-dir ./global_enf_data
```

You can limit downloads to one provider, for example:

```bash
python -m global_enf sync --source NESO --data-dir ./global_enf_data
```

Raw files are stored under `global_enf_data/raw/<source_id>/`. `manifest.jsonl` records the source URL, country/area,
grid identifier, expected resolution (where known), license note, local path, file size, SHA-256 hash, collection time,
and download status. Files are downloaded to a `.part` temporary file and renamed only after a successful transfer.

## Updates

Run `python -m global_enf sync` on a schedule (for example, daily or weekly) on a machine or cloud workspace with
persistent storage. The script discovers the current resources each run and skips files already present. Do not
store the raw archive directory in Git: several annual/monthly datasets are large and some source licences require
attribution or impose redistribution conditions.

## Important limitations

1. **Raw archive collection is not the same as normalized ENF data.** The first iteration archives official source files
   and records provenance. It does not yet parse every XLSB/CSV/ZIP schema into a single canonical time series.
2. AEMO publishes `.xlsb` workbooks; these need a dedicated workbook parser (for example `pyxlsb`) and schema checks.
3. Fingrid's 10 Hz data includes station measurements and local-time/DST details. Preserve station identifiers and original
   timestamps; do not silently average or downsample it.
4. Netztransparenz describes its Continental Europe samples as archived every 1-4 seconds and carried forward. Those
   values are not independent 1 Hz measurements.
5. Zenodo record metadata is retrieved dynamically. A record's existence does not prove that every attached file is a
   frequency time series; inspect metadata, licence, units, sampling rate, and actual contents before importing it.
6. The original OpenENF downloader still downloads the two legacy Zenodo `.freqdb` files for its existing CLI. This
   collector is an additional raw-data layer, not yet wired into the old one-second lookup server.

## Provenance and data handling

- Original source files are never edited in place.
- Each downloaded file receives a SHA-256 checksum.
- Source timestamps, timezone conventions, station identifiers, missing samples, and licence information must be
  retained during future normalization.
- Never merge datasets solely because they share a nominal 50 Hz or 60 Hz base frequency. Confirm synchronous area,
  measurement location, timing reference, and provenance first.


## Relationship to `openenf run`

The `openenf run <audio> --date YYYY-MM-DD [--utc HH:mm:ss]` command uses the legacy lookup engine and its installed `.freqdb` files. The collectors in this directory discover and preserve additional source archives, but those CSV/ZIP/XLSB files are not yet converted into the legacy `.freqdb` format or searched by `run`. Do not interpret a successful archive download as proof that the new country/grid is available to audio lookup.

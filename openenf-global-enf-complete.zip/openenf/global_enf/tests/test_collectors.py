import tempfile
import unittest
from pathlib import Path

from unittest.mock import patch

from global_enf.collectors import (
    Resource,
    append_manifest,
    discover_aemo,
    discover_fingrid,
    download_resource,
    validate_archives,
)


class CollectorTests(unittest.TestCase):
    def test_manifest_is_jsonl(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            append_manifest(root, [{"source_id": "test", "status": "ok"}])
            line = (root / "manifest.jsonl").read_text(encoding="utf-8").strip()
            self.assertIn('"source_id": "test"', line)
            self.assertIn('"collected_at_utc"', line)

    def test_resource_filename_is_kept_in_source_folder(self):
        # A local file URL makes the downloader test independent of external services.
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / "source.csv"
            source.write_text("timestamp,frequency\n2026-01-01T00:00:00Z,50.0\n", encoding="utf-8")
            resource = Resource("test_source", "Test", "Test", "TEST", source.as_uri(), "source.csv", "csv")
            result = download_resource(resource, Path(tmp) / "out")
            self.assertEqual(result["status"], "downloaded_or_refreshed")
            self.assertTrue((Path(tmp) / "out/raw/test_source/source.csv").exists())


    def test_aemo_discovery_accepts_signed_workbook_urls(self):
        links = [
            ("11/11/2026 Mainland frequency data 2026 25 MB", "https://example.test/mainland-frequency-data-2026.xlsb?rev=abc&sc_lang=en"),
            ("11/11/2026 Tasmania frequency data 2026 27 MB", "https://example.test/tasmania-frequency-data-2026.xlsb?rev=def"),
        ]
        with patch("global_enf.collectors._links", return_value=links):
            resources = discover_aemo()
        self.assertEqual(len(resources), 2)
        self.assertTrue(all(item.filename.endswith(".xlsb") for item in resources))

    def test_fingrid_discovery_keeps_archives_with_extensionless_urls(self):
        links = [
            ("Frequency measurement data 2026-09", "https://example.test/api/resource/abc123"),
        ]
        with patch("global_enf.collectors._links", return_value=links):
            resources = discover_fingrid()
        self.assertEqual(len(resources), 1)
        self.assertEqual(resources[0].filename, "fingrid_frequency_2026-09.archive")

    def test_validate_ignores_non_zip_raw_files_without_rewriting_them(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            target = root / "raw" / "test" / "sample.csv"
            target.parent.mkdir(parents=True)
            target.write_text("a,b\n1,2\n", encoding="utf-8")
            result = validate_archives(root)
            self.assertEqual(result[0]["status"], "downloaded_unparsed")
            self.assertEqual(target.read_text(encoding="utf-8"), "a,b\n1,2\n")


if __name__ == "__main__":
    unittest.main()

"""Global ENF raw-data collection layer for OpenENF."""

__version__ = "0.1.0"

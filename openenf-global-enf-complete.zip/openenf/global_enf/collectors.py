from __future__ import annotations

import hashlib
import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from typing import Iterable

USER_AGENT = "OpenENF-GlobalData/0.1 (+https://github.com/openENF/openenf)"
TIMEOUT_SECONDS = 60


@dataclass(frozen=True)
class Resource:
    source_id: str
    source_name: str
    country_or_area: str
    grid_id: str
    url: str
    filename: str
    data_type: str
    expected_resolution: str | None = None
    license: str | None = None
    notes: str | None = None


class _AnchorParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self._href: str | None = None
        self._parts: list[str] = []
        self.links: list[tuple[str, str]] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.lower() == "a":
            self._href = dict(attrs).get("href")
            self._parts = []

    def handle_data(self, data: str) -> None:
        if self._href is not None:
            self._parts.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() == "a" and self._href is not None:
            self.links.append((" ".join(" ".join(self._parts).split()), self._href))
            self._href = None
            self._parts = []


def http_get(url: str, *, accept: str = "*/*") -> tuple[bytes, dict[str, str]]:
    request = urllib.request.Request(
        url,
        headers={"User-Agent": USER_AGENT, "Accept": accept},
        method="GET",
    )
    last_error: Exception | None = None
    for attempt in range(3):
        try:
            with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS) as response:
                return response.read(), {k.lower(): v for k, v in response.headers.items()}
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            last_error = exc
            if attempt < 2:
                time.sleep(2 ** attempt)
    raise RuntimeError(f"GET failed after 3 attempts: {url}: {last_error}")


def _links(page_url: str) -> list[tuple[str, str]]:
    body, _ = http_get(page_url, accept="text/html,application/xhtml+xml")
    parser = _AnchorParser()
    parser.feed(body.decode("utf-8", errors="replace"))
    return [(label, urllib.parse.urljoin(page_url, href)) for label, href in parser.links if href]


def _safe_filename(name: str) -> str:
    name = Path(urllib.parse.unquote(name)).name
    name = re.sub(r"[^A-Za-z0-9._-]+", "_", name).strip("._")
    return name or "download.bin"


def _filename_from_url(url: str) -> str:
    return _safe_filename(urllib.parse.urlparse(url).path.rsplit("/", 1)[-1])


def discover_neso() -> list[Resource]:
    """Discover every CSV resource currently published in NESO's CKAN package."""
    api = "https://api.neso.energy/api/3/action/package_show?id=system-frequency-data"
    payload, _ = http_get(api, accept="application/json")
    data = json.loads(payload)
    if not data.get("success"):
        raise RuntimeError("NESO CKAN package_show returned success=false")
    resources = data.get("result", {}).get("resources", [])
    found: list[Resource] = []
    for item in resources:
        url = item.get("url") or item.get("download_url")
        name = item.get("name") or item.get("url") or ""
        if not url or not (str(name).lower().endswith(".csv") or ".csv" in str(url).lower()):
            continue
        found.append(Resource(
            source_id="neso_system_frequency",
            source_name="National Energy System Operator (NESO)",
            country_or_area="Great Britain",
            grid_id="GB",
            url=url,
            filename=_filename_from_url(url) if ".csv" in str(url).lower() else _safe_filename(str(name) or "neso_frequency.csv"),
            data_type="csv",
            expected_resolution="1 second",
            license="NESO Open Data Licence",
            notes="Times are published in GMT according to the dataset documentation.",
        ))
    return found


def discover_aemo() -> list[Resource]:
    """Discover AEMO's annual mainland and Tasmania frequency workbooks."""
    page = "https://www.aemo.com.au/energy-systems/electricity/national-electricity-market-nem/system-operations/ancillary-services/frequency-and-time-deviation-monitoring"
    found: list[Resource] = []
    pattern = re.compile(r"(Mainland|Tasmania) frequency data\s+(20\d{2})", re.I)
    for label, url in _links(page):
        match = pattern.search(label)
        url_path = urllib.parse.urlparse(url).path.lower()
        if not match or not url_path.endswith((".xlsb", ".xlsx", ".xls")):
            continue
        area = match.group(1).title()
        year = match.group(2)
        found.append(Resource(
            source_id=f"aemo_{area.lower()}_frequency",
            source_name="Australian Energy Market Operator (AEMO)",
            country_or_area="Australia - " + area,
            grid_id="AU-MAINLAND" if area == "Mainland" else "AU-TAS",
            url=url,
            filename=_safe_filename(url.split("?", 1)[0].rsplit("/", 1)[-1]),
            data_type=Path(url.split("?", 1)[0]).suffix.lstrip(".").lower(),
            expected_resolution="Verify in workbook metadata",
            license="Check AEMO terms for the specific file before redistribution",
            notes=f"Annual frequency workbook, {year}; preserve original binary workbook.",
        ))
    return found


def discover_fingrid() -> list[Resource]:
    """Discover monthly archives exposed on Fingrid's historical dataset page."""
    page = "https://data.fingrid.fi/en/datasets/339"
    found: list[Resource] = []
    pattern = re.compile(r"Frequency measurement data\s+(20\d{2})-(\d{2})", re.I)
    for label, url in _links(page):
        match = pattern.search(label)
        if not match:
            continue
        year, month = match.groups()
        filename = _filename_from_url(url)
        if Path(filename).suffix.lower() not in {".zip", ".gz", ".7z", ".rar"}:
            filename = f"fingrid_frequency_{year}-{month}.archive"
        found.append(Resource(
            source_id="fingrid_frequency_10hz",
            source_name="Fingrid",
            country_or_area="Nordic synchronous area (measurements at Finnish 400 kV substations)",
            grid_id="NORDIC",
            url=url,
            filename=filename,
            data_type="archive",
            expected_resolution="10 Hz",
            license="Creative Commons Attribution",
            notes=f"Monthly archive {year}-{month}; source documentation reports possible telemetry gaps and local-time timestamps.",
        ))
    return found


def discover_netztransparenz() -> list[Resource]:
    """Discover downloadable annual Continental Europe frequency archives."""
    page = "https://www.netztransparenz.de/de-de/Regelenergie/Daten-Regelreserve/Sek%C3%BCndliche-Daten"
    found: list[Resource] = []
    pattern = re.compile(r"(20\d{2})_Frequenz", re.I)
    for label, url in _links(page):
        match = pattern.search(label)
        if not match or not url.lower().split("?", 1)[0].endswith(".zip"):
            continue
        year = match.group(1)
        filename = _filename_from_url(url)
        if not filename.lower().endswith(".zip"):
            filename = f"{year}_Frequenz.zip"
        found.append(Resource(
            source_id="netztransparenz_continental_europe",
            source_name="Netztransparenz / German TSOs",
            country_or_area="Continental Europe synchronous area",
            grid_id="DE",
            url=url,
            filename=filename,
            data_type="zip",
            expected_resolution="Archived every 1-4 seconds, then values are carried forward",
            license="Check source terms before redistribution",
            notes=f"Annual archive {year}; timestamps are CET/CEST local time.",
        ))
    return found


def discover_zenodo(record_ids: Iterable[str]) -> list[Resource]:
    found: list[Resource] = []
    for record_id in record_ids:
        api = f"https://zenodo.org/api/records/{urllib.parse.quote(str(record_id))}"
        payload, _ = http_get(api, accept="application/json")
        record = json.loads(payload)
        metadata = record.get("metadata", {})
        title = metadata.get("title", f"Zenodo record {record_id}")
        creators = metadata.get("creators", [])
        creator_text = ", ".join(c.get("name", "") for c in creators if c.get("name"))
        license_id = (metadata.get("license") or {}).get("id")
        for item in record.get("files", []):
            key = item.get("key") or "download.bin"
            links = item.get("links", {})
            url = links.get("self") or links.get("download")
            if not url:
                continue
            found.append(Resource(
                source_id=f"zenodo_{record_id}",
                source_name=f"Zenodo {record_id}: {title}",
                country_or_area="See record metadata",
                grid_id="UNSPECIFIED",
                url=url,
                filename=_safe_filename(key),
                data_type=Path(key).suffix.lstrip(".").lower() or "binary",
                license=license_id,
                notes=f"Record creators: {creator_text or 'not listed'}; inspect record metadata and file contents before use.",
            ))
    return found


def discover_all() -> tuple[list[Resource], list[dict[str, str]]]:
    sources = [
        ("NESO", discover_neso),
        ("AEMO", discover_aemo),
        ("Fingrid", discover_fingrid),
        ("Netztransparenz", discover_netztransparenz),
        ("Zenodo", lambda: discover_zenodo((7741427, 7809233, 5105820, 15784548))),
    ]
    resources: list[Resource] = []
    errors: list[dict[str, str]] = []
    for name, discover in sources:
        try:
            items = discover()
            resources.extend(items)
            print(f"[DISCOVERED] {name}: {len(items)} resources")
        except Exception as exc:  # one broken provider must not block all other providers
            errors.append({"source": name, "error": str(exc)})
            print(f"[WARNING] {name}: {exc}")
    return resources, errors


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _head_metadata(url: str) -> dict[str, str]:
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT}, method="HEAD")
    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS) as response:
            return {
                "etag": response.headers.get("ETag", ""),
                "last_modified": response.headers.get("Last-Modified", ""),
                "content_length": response.headers.get("Content-Length", ""),
            }
    except Exception:
        # Some open-data hosts do not implement HEAD. In that case we keep a
        # verified local copy rather than re-downloading large archives every run.
        return {}


def download_resource(resource: Resource, root: Path) -> dict[str, object]:
    target_dir = root / "raw" / resource.source_id
    target_dir.mkdir(parents=True, exist_ok=True)
    target = target_dir / resource.filename
    sidecar = target.with_suffix(target.suffix + ".source.json")
    remote = _head_metadata(resource.url)

    if target.exists() and target.stat().st_size > 0:
        previous: dict[str, str] = {}
        if sidecar.exists():
            try:
                previous = json.loads(sidecar.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                previous = {}
        same_url = previous.get("url") == resource.url
        same_validator = (
            bool(remote.get("etag") and remote.get("etag") == previous.get("etag"))
            or bool(remote.get("last_modified") and remote.get("last_modified") == previous.get("last_modified"))
            or bool(remote.get("content_length") and remote.get("content_length") == previous.get("content_length"))
        )
        if same_url and (same_validator or not remote):
            return {
                **asdict(resource), "local_path": str(target), "sha256": _sha256(target),
                "bytes": target.stat().st_size, "status": "already_current",
            }

    request = urllib.request.Request(resource.url, headers={"User-Agent": USER_AGENT})
    temp = target.with_suffix(target.suffix + ".part")
    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS) as response, temp.open("wb") as out:
            content_type = response.headers.get("Content-Type", "")
            first = True
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                if first:
                    first = False
                    if "text/html" in content_type.lower() and not resource.url.lower().endswith((".html", ".htm")):
                        raise RuntimeError(f"Expected data file but server returned {content_type}")
                out.write(chunk)
        if not temp.exists() or temp.stat().st_size == 0:
            raise RuntimeError("Downloaded file is empty")
        temp.replace(target)
        sidecar.write_text(json.dumps({"url": resource.url, **remote}, indent=2), encoding="utf-8")
    except Exception:
        temp.unlink(missing_ok=True)
        raise

    return {
        **asdict(resource), "local_path": str(target), "sha256": _sha256(target),
        "bytes": target.stat().st_size, "status": "downloaded_or_refreshed",
    }


def append_manifest(root: Path, records: Iterable[dict[str, object]]) -> None:
    root.mkdir(parents=True, exist_ok=True)
    manifest = root / "manifest.jsonl"
    now = datetime.now(timezone.utc).isoformat()
    with manifest.open("a", encoding="utf-8") as handle:
        for record in records:
            row = {"collected_at_utc": now, **record}
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def validate_archives(root: Path) -> list[dict[str, str]]:
    """Basic integrity checks only; does not reinterpret or modify source files."""
    results: list[dict[str, str]] = []
    for path in (root / "raw").rglob("*") if (root / "raw").exists() else []:
        if not path.is_file() or path.name.endswith(".part"):
            continue
        if path.suffix.lower() == ".zip":
            try:
                with zipfile.ZipFile(path) as archive:
                    bad = archive.testzip()
                results.append({"path": str(path), "status": "ok" if bad is None else f"corrupt_member:{bad}"})
            except Exception as exc:
                results.append({"path": str(path), "status": f"invalid_zip:{exc}"})
        else:
            results.append({"path": str(path), "status": "downloaded_unparsed"})
    return results

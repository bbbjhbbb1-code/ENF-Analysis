# OpenENF JavaScript CLI

Build the TypeScript CLI from this directory:

```bash
npm install
npm run build
```

Run locally after building:

```bash
node dist/index.js run /path/to/file.mp3 --date 2026-11-17
node dist/index.js run /path/to/file.mp3 --date 2026-11-17 --utc 14:32:08
```

The global npm package exposes both `openenf` and the legacy `enf` command. `--date` is required for the `run` subcommand and is a UTC date in `YYYY-MM-DD` format. Without `--utc`, the complete UTC day is searched. With `--utc HH:mm:ss`, only candidate recording starts in that UTC second are searched.

MP3 decoding uses the project's FFmpeg-backed analyzer. Install the FFmpeg executable on the system and ensure it is on `PATH`.

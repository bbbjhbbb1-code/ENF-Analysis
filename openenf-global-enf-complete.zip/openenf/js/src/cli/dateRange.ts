/** Build a UTC search interval for the ENF lookup engine.
 * With date only, search the complete UTC calendar day.
 * With date + time, search candidate recording starts within that UTC second.
 */
export interface DateRange {
    from: Date;
    to: Date;
}

const DATE_PATTERN = /^(\d{4})-(\d{2})-(\d{2})$/;
const TIME_PATTERN = /^(\d{2}):(\d{2}):(\d{2})$/;

export function buildUtcDateRange(dateValue: string, utcTime?: string): DateRange {
    const dateMatch = DATE_PATTERN.exec(dateValue);
    if (!dateMatch) {
        throw new Error(`Invalid --date '${dateValue}'. Use YYYY-MM-DD, for example 2026-11-17.`);
    }

    const year = Number(dateMatch[1]);
    const month = Number(dateMatch[2]);
    const day = Number(dateMatch[3]);
    const dayStart = new Date(Date.UTC(year, month - 1, day));
    if (dayStart.getUTCFullYear() !== year || dayStart.getUTCMonth() !== month - 1 || dayStart.getUTCDate() !== day) {
        throw new Error(`Invalid calendar date '${dateValue}'.`);
    }

    if (utcTime !== undefined) {
        const timeMatch = TIME_PATTERN.exec(utcTime);
        if (!timeMatch) {
            throw new Error(`Invalid --utc '${utcTime}'. Use HH:mm:ss, for example 14:32:08.`);
        }
        const hours = Number(timeMatch[1]);
        const minutes = Number(timeMatch[2]);
        const seconds = Number(timeMatch[3]);
        if (hours > 23 || minutes > 59 || seconds > 59) {
            throw new Error(`Invalid UTC time '${utcTime}'. Hours must be 00-23 and minutes/seconds 00-59.`);
        }
        const from = new Date(Date.UTC(year, month - 1, day, hours, minutes, seconds));
        return {from, to: new Date(from.getTime() + 999)};
    }

    const nextDay = new Date(Date.UTC(year, month - 1, day + 1));
    return {from: dayStart, to: new Date(nextDay.getTime() - 1000)};
}

import {buildUtcDateRange} from "./dateRange";

describe("buildUtcDateRange", () => {
    it("returns the whole UTC day when no time is supplied", () => {
        const range = buildUtcDateRange("2026-11-17");
        expect(range.from.toISOString()).toBe("2026-11-17T00:00:00.000Z");
        expect(range.to.toISOString()).toBe("2026-11-17T23:59:59.000Z");
    });

    it("returns the specified UTC second when a time is supplied", () => {
        const range = buildUtcDateRange("2026-11-17", "08:09:10");
        expect(range.from.toISOString()).toBe("2026-11-17T08:09:10.000Z");
        expect(range.to.toISOString()).toBe("2026-11-17T08:09:10.999Z");
    });

    it("rejects invalid dates and times", () => {
        expect(() => buildUtcDateRange("2026-02-30")).toThrow();
        expect(() => buildUtcDateRange("2026-11-17", "24:00:00")).toThrow();
        expect(() => buildUtcDateRange("17-11-2026")).toThrow();
    });
});

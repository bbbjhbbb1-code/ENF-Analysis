declare module 'compute-kurtosis';
